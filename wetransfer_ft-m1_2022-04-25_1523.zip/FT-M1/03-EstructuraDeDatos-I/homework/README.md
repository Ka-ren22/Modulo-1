# Ejercicios Estructura de Datos

Escribir las soluciones a los ejercicios en `homework.js`.

Para correr los tests, desde la carpeta `homework` ejecutar:

```
npm install
```

```
npm test DataStructure.test.js
```