# Ejercicios Algoritmos



1. QuickSort
	* Implementa el algoritmo según lo explicado en la Lecture

2. MergeSort
	* Implementa el algoritmo según lo explicado en la Lecture

## Extra Credit

3. HeapSort
	* Implementa el algoritmo en:
		* Un árbol binario
		* En un arreglo (recuerden como guardar árboles binarios en un arreglo)
		![ArbolEnArreglo](../img/ayudin.png)

4. BFS y DFS:
	* Implementar un algoritmo para recorrer un árbol de las dos formas.
	* Usar el algoritmo implementado para poder buscar un elemento dentro del árbol.
