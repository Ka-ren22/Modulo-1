# Ejercicios Algoritmos

1. Factoreando Números:
	Se acuerdan como factoreaban números en la escuela? Hagamos un algoritmo para eso! Hay que seguir estos pasos:
	1. Empezamos intentando dividir el número en dos, si el resto es cero, lo seguimos haciendo hasta que no sea cero. En cada pasa agregamos el número como factor.
	2. Pasamos a el siguiente factor que no sea divisible con ningún anterior (en la segunda pasada seria el tres) y dividimos, si el resto es cero, lo agregamos como factor, si no, pasamos al siguiente factor.

	- ¿Cómo implementarían este algoritmo?
	- ¿Funciona bien? Comparen con los resultados de sus compañeros.
	- ¿Qué complejidad tiene el algoritmo que escribieron? ¿Lo pueden mejorar?

2. BubbleSort:
	* Implementar el algoritmo BubbleSort.
	* Agregen funcionalidad para poder medir el tiempo que tarda en ordenar.
	* ¿Como podemos reducir el tiempo? Buscar mejoras de BubbleSort.


2. InsertionSort
	* Implementar el algoritmo InsertionSort.
	* Calculen la complejidad de tu implementación.

3. SelectionSort
	* Implementar el algoritmo SelectionSort.
	* Calculen la complejidad de tu implementación.
