"use strict";

function BinarioADecimal(num) {
  // tu codigo aca
  // algo
}

function DecimalABinario(num) {
  // tu codigo aca
}

// No se pueden usar: 
// parseInt
// toString



module.exports = {
  BinarioADecimal,
  DecimalABinario,
};
